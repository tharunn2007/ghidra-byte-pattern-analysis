package analyzer;

import simple.SimpleDecisionTree;
import simple.SimpleFunction;
import simple.SimpleProgram;

public class FunctionStartAnalyzer {
	 private SimpleDecisionTree decisionTree = new SimpleDecisionTree();

	    public boolean canAnalyze(SimpleProgram program) {
	        return decisionTree.hasPatterns(program);
	    }

	    public void analyze(SimpleProgram program) {
	        if (!canAnalyze(program)) {
	            System.out.println("No patterns found.");
	            return;
	        }

	        System.out.println("Analyzing program: " + program.getName());

	        for (SimpleFunction f : program.getFunctions()) {
	            System.out.println("Detected function: " + f.getName());
	        }
	    }
}
