package core;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class FuncDBsmall {
	private TreeSet<LibraryRecord> libraries = new TreeSet<>();

    public void addLibrary(LibraryRecord lib) {
        libraries.add(lib);
    }

    public List<FuncRecord> query(long hash) {
        List<FuncRecord> result = new ArrayList<>();
        for (LibraryRecord lib : libraries) {
            result.addAll(lib.query(hash));
        }
        return result;
    }
}
