package core;

import java.util.ArrayList;
import java.util.List;

import simple.SimpleFunction;
import simple.SimpleWriter;

public class FuncRecord implements Comparable<FuncRecord>{
	public long hashValue;
    public String funcName;
    public SimpleFunction func;
    public List<FuncRecord> children = new ArrayList<>();

    public FuncRecord() {}

    public FuncRecord(SimpleFunction func) {
        this.func = func;
        this.funcName = func.getName();

        // Simple hash instead of complex instruction hashing
        this.hashValue = func.getInstructions().toString().hashCode();
    }

    @Override
    public int compareTo(FuncRecord o) {
        return Long.compare(this.hashValue, o.hashValue);
    }

    public void saveXml(SimpleWriter writer) {
        writer.write("<func name=\"" + funcName + "\" hash=\"" + hashValue + "\"/>\n");
    }

    @Override
    public String toString() {
        return funcName + " (" + hashValue + ")";
    }
}
