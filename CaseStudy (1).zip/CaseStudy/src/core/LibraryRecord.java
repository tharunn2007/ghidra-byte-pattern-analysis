package core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import simple.SimpleFunction;
import simple.SimpleProgram;

public class LibraryRecord implements Comparable<LibraryRecord>{
	private TreeSet<FuncRecord> records = new TreeSet<>();
    private String libName;

    public LibraryRecord(SimpleProgram program) {
        this.libName = program.getName();

        Map<SimpleFunction, FuncRecord> map = new HashMap<>();

        // Create records
        for (SimpleFunction f : program.getFunctions()) {
            FuncRecord rec = new FuncRecord(f);
            records.add(rec);
            map.put(f, rec);
        }

        // Build call graph
        for (SimpleFunction f : program.getFunctions()) {
            FuncRecord rec = map.get(f);
            for (SimpleFunction called : f.getCalls()) {
                rec.children.add(map.get(called));
            }
        }
    }

    public List<FuncRecord> query(long hash) {
        List<FuncRecord> result = new ArrayList<>();
        for (FuncRecord r : records) {
            if (r.hashValue == hash) {
                result.add(r);
            }
        }
        return result;
    }

    public TreeSet<FuncRecord> getRecords() {
        return records;
    }

    @Override
    public int compareTo(LibraryRecord o) {
        return libName.compareTo(o.libName);
    }
}
