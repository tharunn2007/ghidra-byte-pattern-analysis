package demo;

import analyzer.FunctionStartAnalyzer;
import core.FuncDBsmall;
import core.FuncRecord;
import core.LibraryRecord;
import simple.SimpleFunction;
import simple.SimpleProgram;
import simple.SimpleWriter;

public class Main {

	public static void main(String[] args) {
		SimpleFunction f1 = new SimpleFunction("FuncA", 100);
        f1.addInstruction("LOAD");
        f1.addInstruction("CALL");

        SimpleFunction f2 = new SimpleFunction("FuncB", 200);
        f2.addInstruction("ADD");

        f1.addCall(f2);

        // Program
        SimpleProgram program = new SimpleProgram("DemoProgram");
        program.addFunction(f1);
        program.addFunction(f2);

        // Analyzer
        FunctionStartAnalyzer analyzer = new FunctionStartAnalyzer();
        analyzer.analyze(program);

        // Database
        LibraryRecord lib = new LibraryRecord(program);
        FuncDBsmall db = new FuncDBsmall();
        db.addLibrary(lib);

        long hash = new FuncRecord(f1).hashValue;

        System.out.println("\nQuery Results:");
        db.query(hash).forEach(System.out::println);

        // XML demo
        SimpleWriter writer = new SimpleWriter();
        new FuncRecord(f1).saveXml(writer);

        System.out.println("\nXML Output:");
        System.out.println(writer.getContent());
    }
	

}
