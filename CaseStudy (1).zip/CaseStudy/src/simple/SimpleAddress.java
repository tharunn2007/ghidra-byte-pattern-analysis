package simple;

public class SimpleAddress {
	private long value;

    public SimpleAddress(long value) {
        this.value = value;
    }

    public long getValue() {
        return value;
    }

    @Override
    public String toString() {
        return "Addr_" + value;
    }
}
