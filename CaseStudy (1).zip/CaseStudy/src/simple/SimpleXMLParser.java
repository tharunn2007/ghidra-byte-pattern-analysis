package simple;

import java.util.HashMap;
import java.util.Map;

public class SimpleXMLParser {
	private Map<String, String> attributes = new HashMap<>();

    public void setAttribute(String key, String value) {
        attributes.put(key, value);
    }

    public String get(String key) {
        return attributes.get(key);
    }
}
