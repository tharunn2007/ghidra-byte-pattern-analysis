package simple;

import java.util.ArrayList;
import java.util.List;

public class SimpleProgram {
	private String name;
    private List<SimpleFunction> functions = new ArrayList<>();

    public SimpleProgram(String name) {
        this.name = name;
    }

    public void addFunction(SimpleFunction f) {
        functions.add(f);
    }

    public List<SimpleFunction> getFunctions() {
        return functions;
    }

    public String getName() {
        return name;
    }
}
