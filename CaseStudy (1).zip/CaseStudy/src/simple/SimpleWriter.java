package simple;

public class SimpleWriter {
	private StringBuilder sb = new StringBuilder();

    public void write(String s) {
        sb.append(s);
    }

    public String getContent() {
        return sb.toString();
    }
}
