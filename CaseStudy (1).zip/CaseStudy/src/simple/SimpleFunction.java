package simple;

import java.util.ArrayList;
import java.util.List;

public class SimpleFunction {
	private String name;
    private List<String> instructions = new ArrayList<>();
    private List<SimpleFunction> calls = new ArrayList<>();
    private SimpleAddress address;

    public SimpleFunction(String name, long addr) {
        this.name = name;
        this.address = new SimpleAddress(addr);
    }

    public void addInstruction(String instr) {
        instructions.add(instr);
    }

    public void addCall(SimpleFunction f) {
        calls.add(f);
    }

    public String getName() {
        return name;
    }

    public List<String> getInstructions() {
        return instructions;
    }

    public List<SimpleFunction> getCalls() {
        return calls;
    }

    public SimpleAddress getAddress() {
        return address;
    }

    @Override
    public String toString() {
        return name;
    }
}
