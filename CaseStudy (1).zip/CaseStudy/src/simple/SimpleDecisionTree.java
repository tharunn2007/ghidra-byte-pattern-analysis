package simple;

public class SimpleDecisionTree {
	public boolean hasPatterns(SimpleProgram program) {
        return true; // always true for demo
    }
}
